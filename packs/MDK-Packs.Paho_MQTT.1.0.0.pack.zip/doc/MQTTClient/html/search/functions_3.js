var searchData=
[
  ['expired',['expired',['../class_countdown.html#acaed3caa70c060c44deef059e311cfa5',1,'Countdown']]]
];
