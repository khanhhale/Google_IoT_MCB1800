var searchData=
[
  ['left_5fms',['left_ms',['../class_countdown.html#a4f8729eb66d4cf8cb6a8ec00cef9ee84',1,'Countdown']]]
];
