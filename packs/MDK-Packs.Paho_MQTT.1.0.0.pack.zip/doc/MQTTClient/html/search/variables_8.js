var searchData=
[
  ['sessionpresent',['sessionPresent',['../struct_m_q_t_t_1_1connack_data.html#a35ea742eccdd29035dd59a7af3aeb2cd',1,'MQTT::connackData']]]
];
