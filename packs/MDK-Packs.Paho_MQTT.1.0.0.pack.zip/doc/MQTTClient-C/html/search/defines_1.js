var searchData=
[
  ['max_5fmessage_5fhandlers',['MAX_MESSAGE_HANDLERS',['../_m_q_t_t_client_8h.html#a097fe1f2aed537fea5c806f7c231535e',1,'MQTTClient.h']]],
  ['max_5fpacket_5fid',['MAX_PACKET_ID',['../_m_q_t_t_client_8h.html#aa6ae71e8be050e41896f2a66231396fe',1,'MQTTClient.h']]]
];
