var searchData=
[
  ['linux_5fread',['linux_read',['../_m_q_t_t_linux_8c.html#af612c1d779631b024d1be0265a19f0ea',1,'linux_read(Network *n, unsigned char *buffer, int len, int timeout_ms):&#160;MQTTLinux.c'],['../_m_q_t_t_linux_8h.html#a57bdf062697f9f4fa5097692941b3c61',1,'linux_read(Network *, unsigned char *, int, int):&#160;MQTTLinux.c']]],
  ['linux_5fwrite',['linux_write',['../_m_q_t_t_linux_8c.html#ae717de203a4c356e7d3f2bdd8a30ae98',1,'linux_write(Network *n, unsigned char *buffer, int len, int timeout_ms):&#160;MQTTLinux.c'],['../_m_q_t_t_linux_8h.html#a20adeecdd8e52be9160da3019251ee3d',1,'linux_write(Network *, unsigned char *, int, int):&#160;MQTTLinux.c']]]
];
