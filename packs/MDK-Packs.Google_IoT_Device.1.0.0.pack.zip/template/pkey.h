/*
 * PEM-encoded device private key.
 *
 * Must include the PEM header and footer:
 * "-----BEGIN EC PRIVATE KEY-----\n"
 * "...base64 data...\n"
 * "-----END EC PRIVATE KEY-----\n";
 *  ---- or ----
 * "-----BEGIN RSA PRIVATE KEY-----\n"
 * "...base64 data...\n"
 * "-----END RSA PRIVATE KEY-----\n";
 */
static const char PrivateKey[] = "";
